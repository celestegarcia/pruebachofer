import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-grua',
  templateUrl: 'grua.html'
})
export class GruaPage {

  constructor(public navCtrl: NavController) {
  }
  
}
